<?php

namespace database;
class commondao
{
    public $module = 'DB_commondao';
    public $log;
    public $dbconnect;

    function __construct()
    {
        $this->log = new \util\logger();
    }

    public function getProjectList()
    {
        try {
            $this->log->logIt($this->module . ' - getProjectList');
            $dao = new \dao();

            $strSql = 'SELECT  PRJ.id, PRJ.project FROM user_project_assign AS UP INNER JOIN projects AS PRJ ON PRJ.id =  UP.projectid WHERE UP.userid=' . $_SESSION[$_SESSION['prefix_crm']]['userid'];

            $dao->initCommand($strSql);
            $data = $dao->executeQuery();

            return $data;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getProjectList - ' . $e);
        }
    }

    public function getProject($data)
    {
        try {
            $this->log->logIt($this->module . ' - getProject');
            $dao = new \dao();
            $id = (isset($data['id'])) ? $data['id'] : "";
            $strSql = "SELECT * from projects WHERE id='" . $id . "'";


            $dao->initCommand($strSql);

            $dao->addParameter(':id', $id);

            $data = $dao->executeRow();

            return json_encode(array("Success" => "True", "Data" => $data));

        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getProject - ' . $e);
        }
    }

    public function getList($limit, $offset, $name)
    {
        try {
            $this->log->logIt($this->module . ' - getList - ' . $limit . ' - ' . $offset . ' - ' . $name);
            $dao = new \dao();

            $strSql = 'SELECT * FROM projects WHERE is_deleted=0';
            if ($name != "") {
                // $this->log->logIt('here');
                $strSql .= " and project LIKE '%" . $name . "%' ";

            }
            /*else{
                $this->log->logIt('here in else');
            }*/
            if ($limit != "" && ($offset != "" || $offset != 0)) {
                $strSqllmt = " LIMIT " . $limit . " OFFSET " . $offset;
            }
            $dao->initCommand($strSql);

            $data = $dao->executeQuery();

            if ($limit != "" && ($offset != "" || $offset != 0))
                $dao->initCommand($strSql . $strSqllmt);
            else
                $dao->initCommand($strSql);
            $rec = $dao->executeQuery();

            if (count($data) != 0) {

                $retvalue = array(array("cnt" => count($data), "data" => $rec));
                return json_encode($retvalue);
            } else {
                $retvalue = array(array("cnt" => 0, "data" => []));
                return json_encode($retvalue);
            }
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getProject - ' . $e);
        }
    }

    public function removeproject($data)
    {
        try {
            $this->log->logIt($this->module . ' - remove project');

            $dao = new \dao();
           
            $strSql = "UPDATE projects SET is_deleted=1 WHERE id=:id";
            $dao->initCommand($strSql);
            $dao->addParameter(':id', $data['id']);
            $dao->executeNonQuery();
            return json_encode(array('Success' => 'True', 'Message' => 'project removed Successfully'));
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - remove project- ' . $e);
        }
    }

    public function getemployeeList()
    {
        try {
            $this->log->logIt($this->module . ' - getemployeeList');
            $dao = new \dao();
            if ($_SESSION[$_SESSION['prefix_crm']]['is_tl'] != '1' && $_SESSION[$_SESSION['prefix_crm']]['is_superuser'] != '1') {
                return array();
            }
            $strSql = 'SELECT name,id FROM user WHERE 1 ';
            if ($_SESSION[$_SESSION['prefix_crm']]['is_tl'] == '1')
                $strSql .= ' AND id IN (' . $_SESSION[$_SESSION['prefix_crm']]['auth_user'] . ')';

            $dao->initCommand($strSql);
            $data = $dao->executeQuery();
            return $data;

        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getemployeeList - ' . $e);
        }
    }

    public function addedittask($data)
    {
        try {
            $this->log->logIt($this->module . ' - addedittask');
            $dao = new \dao();

            $date = \util\util::convertDateToMySql($data['date']);
            $strSql = "INSERT INTO dailytask SET projectid=" . $data['select_project'] . ", "
                . " description='" . $data['description'] . "', time='" . $data['hour'] . ":" . $data['min'] . "', date='" . $date . "', entrydatetime=NOW(),userid=" . $_SESSION[$_SESSION['prefix_crm']]['userid'];
            $dao->initCommand($strSql);
            $dao->executeNonQuery();

            return json_encode(array('Success' => 'True', 'Message' => 'Task Saved Successfully'));

        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - addedittask - ' . $e);
            return json_encode(array('Success' => 'True', 'Message' => 'Task Saved Successfully'));
        }
    }

    public function addprojects($data)
    {
        try {
            $this->log->logIt($this->module . ' - addprojects');
            $dao = new \dao();
            $this->log->logIt($data['id']);
            if ($data['id'] == '0' || $data['id'] == 0) {
                $strSql = "INSERT INTO projects SET project=:project ";

                $dao->initCommand($strSql);
                $this->log->logIt($strSql);
                $dao->addParameter(':project', $data['project']);
                $dao->executeNonQuery();

                return json_encode(array('Success' => 'True', 'Message' => 'Projects Saved Successfully'));

            } else {
                $strSql = "Update projects SET project='" . $data['project'] . "' where id='" . $data['id'] . "' ";

                $dao->initCommand($strSql);
                $this->log->logIt($strSql);
                $dao->addParameter(':project', $data['project']);

                $dao->addParameter(':id', $data['id']);
                $dao->executeNonQuery();

                return json_encode(array('Success' => 'True', 'Message' => 'Projects Updated Successfully'));
            }


        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - addprojects - ' . $e);
            return json_encode(array('Success' => 'True', 'Message' => 'Projects Saved Successfully'));
        }
    }

    public function remove_task($data)
    {
        try {
            $this->log->logIt($this->module . ' - remove_task');
            $dao = new \dao();
            $strSql = "DELETE FROM dailytask WHERE id=:id AND userid=:userid";
            $dao->initCommand($strSql);
            $dao->addParameter(':id', $data['id']);
            $dao->addParameter(':userid', $_SESSION[$_SESSION['prefix_crm']]['userid']);
            $dao->executeNonQuery();
            return json_encode(array('Success' => 'True', 'Message' => 'Task removed Successfully'));
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - remove_task - ' . $e);
        }
    }

    public function loadtasklist($limit, $offset, $emp = '')
    {
        try {
            $this->log->logIt($this->module . ' - loadtasklist');
            $dao = new \dao();
            if ($emp == '')
                $emp = $_SESSION[$_SESSION['prefix_crm']]['userid'];

            $strSql = "SELECT dailytask.id, projects.project, dailytask.description, dailytask.time, DATE_FORMAT(dailytask.date, '%d/%m/%Y') AS date, dailytask.entrydatetime FROM dailytask INNER JOIN projects ON projects.id = dailytask.projectid WHERE userid=" . $emp;

            $strSql .= " ORDER BY dailytask.date DESC";

            if ($limit != "" && ($offset != "" || $offset != 0)) {
                $strSqllmt = " LIMIT " . $limit . " OFFSET " . $offset;
            }

            $dao->initCommand($strSql);
            $data = $dao->executeQuery();

            if ($limit != "" && ($offset != "" || $offset != 0))
                $dao->initCommand($strSql . $strSqllmt);
            else
                $dao->initCommand($strSql);

            $rec = $dao->executeQuery();
            $retarr = array();
            $rearr = array();
            $i = -1;
            $sum = strtotime('00:00:00');
            foreach ($rec AS $val) {
                if (isset($retarr[$val['date']])) {
                    $retarr[$val['date']]['detail'][] = $val;
                    $rearr[$i]['detail'][] = $val;

                } else {

                    $i++;
                    $retarr[$val['date']]['date'] = $val['date'];
                    $retarr[$val['date']]['detail'] = array();
                    $retarr[$val['date']]['detail'][] = $val;
                    $sum2 = 0;
                    $rearr[$i]['date'] = $val['date'];
                    $rearr[$i]['detail'] = array();
                    $rearr[$i]['detail'][] = $val;
                }
                $sum1 = strtotime($val['time']) - $sum;
                $sum2 = $sum2 + $sum1;
                $sum3 = $sum + $sum2;
                $rearr[$i]['total_time'] = date("H:i:s", $sum3);

            }
            if (count($data) != 0) {
                $retvalue = array(array("cnt" => count($data), "data" => $rearr));
                return json_encode($retvalue);
            } else {
                $retvalue = array(array("cnt" => 0, "data" => []));
                return json_encode($retvalue);
            }
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - loadcompanylist - ' . $e);
        }
    }

    public function editproject($data)
    {
        try {
            $this->log->logIt($this->module . ' - editproject');

            $dao = new \dao();


            return 1;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - editproject - ' . $e);
            return 0;
        }
    }
}

?>