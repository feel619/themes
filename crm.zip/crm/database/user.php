<?php

namespace database;
class user
{
    public $module = 'DB_user';
    public $log;
    public $dbconnect;

    function __construct()
    {
        $this->log = new \util\logger();
    }
    public function getList($limit, $offset, $name)
    {
        try {
            $this->log->logIt($this->module . ' - getList - ' . $limit . ' - ' . $offset . ' - ' . $name);
            $dao = new \dao();

            $strSql = 'SELECT * FROM user WHERE is_deleted!=1 ';
            if ($name != "") {
                // $this->log->logIt('here');
                $strSql .= " and name LIKE '%" . $name . "%' ";

            }
            /*else{
                $this->log->logIt('here in else');
            }*/
            if ($limit != "" && ($offset != "" || $offset != 0)) {
                $strSqllmt = " LIMIT " . $limit . " OFFSET " . $offset;
            }
            $dao->initCommand($strSql);

            $data = $dao->executeQuery();

            if ($limit != "" && ($offset != "" || $offset != 0))
                $dao->initCommand($strSql . $strSqllmt);
            else
                $dao->initCommand($strSql);
            $rec = $dao->executeQuery();

            if (count($data) != 0) {

                $retvalue = array(array("cnt" => count($data), "data" => $rec));
                return json_encode($retvalue);
            } else {
                $retvalue = array(array("cnt" => 0, "data" => []));
                return json_encode($retvalue);
            }
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getList - ' . $e);
        }
    }

    public function removeuser($data)
    {
        try {
            $this->log->logIt($this->module . ' - remove user');

            $dao = new \dao();
            $strSql = "UPDATE user SET is_deleted=1 WHERE id=:id";
            $dao->initCommand($strSql);
            $dao->addParameter(':id', $data['id']);
            $dao->executeNonQuery();
            return json_encode(array('Success' => 'True', 'Message' => 'user removed Successfully'));
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - remove user- ' . $e);
        }
    }


    public function adduser($data)
    {
        try {
            $this->log->logIt($this->module . ' - adduser');
           
            $dao = new \dao();
            $is_superuser = (isset($data['is_superuser'])) ? 1 : 0;
            $is_tl = (isset($data['is_tl'])) ? 1 : 0;
           
            if ($data['id'] == '0' || $data['id'] == 0) {
                if($is_tl==1){
                    $user = implode($data["user"],",");    
                }else{
                    $user = "";
                }
                
                $privileges = implode($data["privileges"],",");
                $strSql = "INSERT INTO user SET name=:name,username=:username,password=:password, is_superuser=:is_superuser, is_tl=:is_tl, privileges=:privileges, auth_user=:auth_user ";
                $dao->initCommand($strSql);

                $dao->addParameter(':name', $data['name']);
                $dao->addParameter(':username', $data['username']);
                $dao->addParameter(':password', $data['password']);
                $dao->addParameter(':is_superuser', $is_superuser);
                $dao->addParameter(':is_tl', $is_tl);
                $dao->addParameter(':privileges', $privileges);
                $dao->addParameter(':auth_user', $user);
                $dao->executeNonQuery();
                $userid = $dao->getLastInsertedId();
                $projectlist = $data['project'];

                foreach ($projectlist as $value) {
                    $str = "INSERT INTO user_project_assign	SET userid=:userid,projectid=:projectid";
                    $dao->initCommand($str);
                    $dao->addParameter(':userid', $userid);
                    $dao->addParameter(':projectid', $value);
                    $dao->executeNonQuery();
                }
                return json_encode(array('Success' => 'True', 'Message' => 'User Saved Successfully'));
            } else {
                if($is_tl==1){
                    $user = implode($data["user"],",");    
                }else{
                    $user = "";
                }
                $privileges = implode($data["privileges"],",");
                $projectlist = $data['project'];
                
                $str = "DELETE FROM user_project_assign WHERE userid='" . $data['id'] . "' ";

                $dao->initCommand($str);
                $dao->addParameter(':id', $data['id']);
                $dao->executeNonQuery();

                $strSql = "Update user SET name=:name,username=:username,is_superuser=:is_superuser,is_tl=:is_tl, privileges=:privileges, auth_user=:auth_user  where id=:id ";

                $dao->initCommand($strSql);
                $dao->addParameter(':name', $data['name']);
                $dao->addParameter(':username', $data['username']);
                $dao->addParameter(':is_superuser', $is_superuser);
                $dao->addParameter(':is_tl', $is_tl);
                $dao->addParameter(':privileges', $privileges);
                $dao->addParameter(':auth_user', $user);
                $dao->addParameter(':id', $data['id']);
                $dao->executeNonQuery();

                foreach ($projectlist as $value) {
                    $str = "INSERT INTO user_project_assign	 SET userid=:userid,projectid=:projectid";
                    $dao->initCommand($str);
                    $dao->addParameter(':userid', $data['id']);
                    $dao->addParameter(':projectid', $value);
                    $dao->executeNonQuery();
                }
                return json_encode(array('Success' => 'True', 'Message' => 'User Updated Successfully'));
            }

        } catch
        (Exception $e) {
            $this->log->logIt($this->module . ' - adduser - ' . $e);
            return json_encode(array('Success' => 'True', 'Message' => 'User Saved Successfully'));
        }
    }

    public function edituser($data)
    {
        try {
            $this->log->logIt($this->module . ' - edituser');
            $dao = new \dao();
            $SQLQry = "SELECT USR.name,USR.username,USR.is_superuser,USR.is_tl,IFNULL(USR.privileges,'') AS privileges,IFNULL(USR.auth_user,'') AS auth_user,IFNULL(group_concat(PA.projectid),'') AS project  FROM user AS USR 
                LEFT JOIN user_project_assign AS PA ON USR.id = PA.userid WHERE USR.id=:id GROUP BY USR.id;";
            $dao->initCommand($SQLQry);
            $dao->addParameter(':id', $data['id']);
            $rec = $dao->executeRow();
            return $rec;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - edituser - ' . $e);
            return 0;
        }
    }
    public function getUserList()
    {
        try {
            $this->log->logIt($this->module . ' - getUserList');
            $dao = new \dao();
            $SQLQry="SELECT id, name FROM user WHERE is_deleted=0";
            $dao->initCommand($SQLQry);
           
            $data = $dao->executeQuery();   
            return $data;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getUserList - ' . $e);
            return 0;
        }
    }
}

?>