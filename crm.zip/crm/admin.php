<?php
require_once "common/common.php";

$action = $_REQUEST['action'];

$ObjModule = new $action();
$ObjModule->load();

?>