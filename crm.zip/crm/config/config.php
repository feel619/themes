<?php
global $server,$mysqlhost,$mysqluser,$mysqlpwd,$commonurl,$dbname;

$servername = $_SERVER['HTTP_HOST'];

if($servername=='192.168.0.42')
{
    $server	= "local";
    $commonurl = "http://192.168.0.42/projects/crm/";
    $mysqlhost = "localhost";
    $mysqluser = "root";
    $mysqlpwd = "root";
    $dbname = "crm_db";
}
else if($servername=='localhost'){
    $server	= "live";
    $commonurl = "http://localhost/crm/";
    $mysqlhost = "localhost";
    $mysqluser = "root";
    $mysqlpwd = "root";
    $dbname = "crm_db";
}
else{
    $server	= "live";
    $commonurl = "http://oa.vetron.in/";
    $mysqlhost = "localhost";
    $mysqluser = "oavetron";
    $mysqlpwd = "vetron@Vesu";
    $dbname = "dailytask_db";
}
?>