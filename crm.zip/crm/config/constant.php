<?php
    define('CONFIG_UNAME',$_SESSION[$_SESSION['prefix_crm']]['username']);
    define('CONFIG_UID',$_SESSION[$_SESSION['prefix_crm']]['userid']);
    define('CONFIG_ISU',$_SESSION[$_SESSION['prefix_crm']]['is_superuser']);
    define('CONFIG_ITL',$_SESSION[$_SESSION['prefix_crm']]['is_tl']);
    define('CONFIG_AUTH',$_SESSION[$_SESSION['prefix_crm']]['auth_user']);
    define('CONFIG_PRVLG',$_SESSION[$_SESSION['prefix_crm']]['privileges']);
    global $senderarr;
    
    $senderarr["GLOB_UNAME"] = CONFIG_UNAME;
    $senderarr["GLOB_UID"] = CONFIG_UID;
    $senderarr["GLOB_ISU"] = CONFIG_ISU;
    $senderarr["GLOB_ITL"] = CONFIG_ITL;
    $senderarr["GLOB_PRVLG"] = CONFIG_PRVLG;
    
?>