$(document).ready(function(){
   jQuery("#logout").click(function(){
        jQuery.ajax({
            url: "controller",
            type: "post",
            data: "service=logout&opcode=load",
            success: function(data){
                if(data == 1)
                {
                    window.location = "../index.php";
                }
            }
        });
   });
});
function showjQloading() {
   jQuery("#content").addClass('loader');
}
function hidejQloading(){
   jQuery("#content").removeClass('loader');
}

function PrintElem(elem)
{
      var mywindow = window.open('', 'PRINT', 'height=400,width=600');


      mywindow.document.write('<html><head><title>' + document.title  + '</title>');

      mywindow.document.write('</head><body >');
     
      mywindow.document.write(document.getElementById(elem).innerHTML);
      mywindow.document.write('</body></html>');

      mywindow.document.close(); // necessary for IE >= 10
      mywindow.focus(); // necessary for IE >= 10*/

      mywindow.print();
      mywindow.close();

      return true;

}
        
function check_audit_activity(id,module)
{
   try
   {
      jQuery.ajax({
            url: "audit_individual_activity",
            type: "post",
            data: "id="+id+"&module="+module,
            success: function(data){
                  jQuery("#modalPrimary").html(data);
                  jQuery("#modalPrimary").modal('show');
            }
      });
   }
   catch(e)
   {
      alert(e);
   }
}

function check_related_records(id,module)
{
   try
   {
      jQuery.ajax({
          url: "check_dependency",
          type: "post",
          data: "id="+id+"&module="+module,
          success: function(data){
              jQuery("#modalPrimary").html(data);
              jQuery("#modalPrimary").modal('show');
          }
      });
   }
   catch(e)
   {
       alert(e);
   }
}

function displaysettings_activity(module)
{
   try
   {
      jQuery.ajax({
            url: "displaysettings_activity",
            type: "post",
            data: "module="+module,
            success: function(data){
                  jQuery("#modalPrimary").html(data);
                  jQuery("#modalPrimary").modal('show');
            }
      });
   }
   catch(e)
   {
      alert(e);
   }
}

$(document).ready(function() {
    $(".integer").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
             // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
             // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    $(".negativeint").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            //Allow: '-'
            ((e.keyCode == 109 || e.keyCode == 189) && e.ctrlKey === true) ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
            // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105) && (e.keyCode!=109 && e.keyCode!=189)) {
            e.preventDefault();
        }
    });
});
function urldecode (str) {
  return decodeURIComponent((str + '').replace(/\+/g, '%20'));
}
function urlencode (str) {
  return encodeURIComponent(str);
}
function HttpSendRequest($data,action)
{
   $.ajax({
      type: 'POST',
      url: 'controller',
      data: $data,
      dataType: 'json',
      cache: false,
      contentType: false,
      processData: false,
      success: function(data) {
          return action(data);
      },
   });
}
function CallAuthenticatedApi($url,$data,$headers,action)
{
    var authToken = jQuery.getAthtkn();
    $.ajax({
        type: 'POST',
        url: $url,
        data: $data,
        dataType: 'json',
        cache: false,
        contentType: false,
        processData: false,
        beforeSend: function(request) {
            request.setRequestHeader("Content-Type", "application/json");
            request.setRequestHeader("app-id", app_id);
            request.setRequestHeader("app-secret", app_secret);
            request.setRequestHeader("auth-token", authToken);
        },
        error: function(data) {
            if(data.status == 401)
            {
                jQuery.removeAuthtkn();
                window.location = siteUrl+"login.php";
            }
            var errObj = JSON.parse(data.responseText);
            callback_error(action,data);
        },
        success: function(data) {
            console.log("in succ..");
            var res = action(data);
            return res;
        },
    });
}


function validate_form() {
    var error = 0;
    if ($("#name").val() == 0) {
        error = 1;
        $('#name').addClass('invalid');
    }
    else {
        return true;
    }
    if ($("#username").val() == 0) {
        error = 1;
        $('#username').addClass('invalid');
    }
    else {
        return true;
    }
    if ($("#password").val() == 0) {
        error = 1;
        $('#password').addClass('invalid');
    }
    else {
        return true;
    }
}



function validemail(email)
{
   var atpos = email.indexOf("@");
   var dotpos = email.lastIndexOf(".");
   if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) {
      return 0;
   }
   else{
      return 1;
   }
}
function load_report(rec){
   HttpSendRequest(rec, function(data) {
      if (data.Success=="True") {
          jQuery("#content").hide();
          jQuery("#report_content").show();
          jQuery("#print_content").html(data.Data);
      }
   });
}
function Exitinvoice(){
      jQuery("#content").show();
      jQuery("#report_content").hide();
      jQuery("#print_content").empty();
}
function escapeHtml(text) {
    if (isNaN(text)) {
        return text.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#039;/g, "'");
    } else {
        return text;
    }
}

unscaping = function (obj) {
    if ($.isArray(obj)) {
        var str = [];
    } else {
        var str = {};
    }
    var p;
    for (p in obj) {
        if (obj.hasOwnProperty(p)) {
            v = obj[p];
            if (v !== null && (typeof v === "object" || $.isArray(v))) {
                str[p] = unscaping(v);
            } else {
                str[p] = escapeHtml(v);
            }
        }
    }
    return str;
}
