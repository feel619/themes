        // function validate_employee()
        // {
        //     var error=0;
        //     var err_msg = "";
        //     //personal details
        //       $('#txtfname').css('border','1px solid green'); 
        //       $('#txtlname').css('border','1px solid green');
        //       $('#date_of_birth').css('border','1px solid green');
        //       $('#maritial_status').css('border','1px solid green'); 
        //       $('#txtfathername').css('border','1px solid green');
        //       $('#txtnationality').css('border','1px solid green');
        //     //personal details
        
        //     //contact details
        //       $('#txtaddress').css('border','1px solid green');
        //       $('#txtcity').css('border','1px solid green');
        //       $('#select_state').css('border','1px solid green');
        //       $('#txtmobileno').css('border','1px solid green');
        //       $('#txtphoneno').css('border','1px solid green');
        //       $('#txtcompanyno').css('border','1px solid green');
        //       $('#txtemergencyno').css('border','1px solid green');
        //       $('#txtemail').css('border','1px solid green');
        //     //contact details
        //     /*
        //     //documents
        //       $('#upload_photo').css('border','1px solid green');
        //       $('#upload_resume').css('border','1px solid green');
        //       $('#offer_letter').css('border','1px solid green');
        //       $('#joining_letter').css('border','1px solid green');
        //       $('#id_proof').css('border','1px solid green');
        //     //documents
        
        //     //Bank details
        //       $('#txtbankname').css('border','1px solid green');
        //       $('#txtbankbranch').css('border','1px solid green');
        //       $('#txtaccountname').css('border','1px solid green');
        //       $('#txtaccountno').css('border','1px solid green');
        //     //Bank details
        
        //     //official details
        //       $('#txtemployeeid').css('border','1px solid green');
        //       $('#select_branch').css('border','1px solid green');
        //       $('#select_dept').css('border','1px solid green');
        //       $('#select_position').css('border','1px solid green');
        //       $('#joining_date').css('border','1px solid green');
        //       $('#select_probation_time').css('border','1px solid green');
        //       $('#select_notice_period').css('border','1px solid green');
        //     //official details
        
        //     //salary details
        //       $('#txtsalary').css('border','1px solid green');
        //       $('#txtpoints').css('border','1px solid green');
        //       $('#select_kra').css('border','1px solid green');
        //       var type = $('input[name=rdo_salary_type]:checked').val();
        //       $('#txthra').css('border','1px solid green');
        //       $('#txtconveyance').css('border','1px solid green');
        //       $('#txtmdclallowance').css('border','1px solid green');
        //       $('#txtfuelallowance').css('border','1px solid green');
        //       $('#txtpfamt').css('border','1px solid green');
        //       $('#txtesiamt').css('border','1px solid green');
        //       $('#txtptamt').css('border','1px solid green');
        //       $('#txtdbtamt').css('border','1px solid green');
        //       $('#txttds').css('border','1px solid green');
        //     //salary details
        //   */
        //     /*personal details*/
        //       if($("#txtfname").val()=="")
        //       {
        //           error=1;
        //           $('#txtfname').css('border','1px solid red');
        //           err_msg += "First name is required";
        //       }
        //       if($("#txtlname").val()=="")
        //       {
        //           error=1;
        //           $('#txtlname').css('border','1px solid red');
        //           err_msg += "\nLast name is required";
        //       }
        //       if($("#date_of_birth").val()=="")
        //       {
        //           error=1;
        //           $('#date_of_birth').css('border','1px solid red');
        //           err_msg += "\nDate of birth is required";
        //       }
        //       if($("#maritial_status").val()==0)
        //       {
        //           error=1;
        //           $('#maritial_status').css('border','1px solid red');
        //           err_msg += "\nMaritial status is required";
        //       }
        //       if($("#txtfathername").val()=="")
        //       {
        //           error=1;
        //           $('#txtfathername').css('border','1px solid red');
        //           err_msg += "\nFather's name is required";
        //       }
        //       if($("#txtnationality").val()=="")
        //       {
        //           error=1;
        //           $('#txtnationality').css('border','1px solid red');
        //           err_msg += "\nNationality is required";
        //       }
        //     /*personal details*/
        
        //     /*contact details*/
        //       if($("#txtaddress").val()=="")
        //       {
        //           error=1;
        //           $('#txtaddress').css('border','1px solid red');
        //           err_msg += "\nAddress is required";
        //       }
        //       if($("#txtcity").val()=="")
        //       {
        //           error=1;
        //           $('#txtcity').css('border','1px solid red');
        //           err_msg += "\nCity name is required";
        //       }
        //       if($("#select_state").val()==0)
        //       {
        //           error=1;
        //           $('#select_state').css('border','1px solid red');
        //           err_msg += "\nPlease select State";
        //       }
        //       if($("#txtmobileno").val()=="")
        //       {
        //           error=1;
        //           $('#txtmobileno').css('border','1px solid red');
        //           err_msg += "\nMobile No is required";
        //       }
        //       else
        //       {   
        //           var regex = /^\d{10}$/;
        //           var input = $("#txtmobileno").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtmobileno').css('border','1px solid red');
        //               err_msg += "\nPlease enter a valid mobile no";
        //           }
        //       }
        
        //       /*if($("#txtphoneno").val()=="")
        //       {
        //           error=1;
        //           $('#txtphoneno').css('border','1px solid red');
        //       }*/
        //       if($("#txtphoneno").val()!="")
        //       {   
        //           var regex = /^\d{10}$/;
        //           var input = $("#txtphoneno").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtphoneno').css('border','1px solid red');
        //               err_msg += "\nPlease enter a valid phone no";
        //           }
        //       }
        //       if($("#txtemergencyno").val()=="")
        //       {
        //           error=1;
        //           $('#txtemergencyno').css('border','1px solid red');
        //           err_msg += "\nEmergency contact no is required";
        //       }
        //       else
        //       {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtemergencyno").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtemergencyno').css('border','1px solid red');
        //               err_msg += "\nPlease enter a valid emergency no";
        //           }
        //       }
        //       /*if($("#txtcompanyno").val()=="")
        //       {
        //           error=1;
        //           $('#txtcompanyno').css('border','1px solid red');
        //           err_msg += "\nCompany contact no is required";
        //       }
        //       else
        //       {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtcompanyno").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtcompanyno').css('border','1px solid red');
        //               err_msg += "\nPlease enter a valid Company contact no";
        //           }
        //       }*/
        //       if($("#txtemail").val()=="")
        //       {
        //           error=1;
        //           $('#txtemail').css('border','1px solid red');
        //           err_msg += "\nEmail address is required";
        //       }
        //       else
        //       {
        //           var regex = /^[\w]+(\.[\w]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/ ;
        //           var email=document.getElementById('txtemail');
        //           if(!regex.test(email.value))
        //           {
        //               $('#txtemail').css('border','1px solid red');
        //               error=1;
        //               err_msg += "\nPlease enter a valid email address";
        //           }
        //       }
        //     /*contact details*/
                
        //     /*documents*/
        //       /*if($("#upload_photo").val()=="")
        //       {
        //           error=1;
        //           $('#upload_photo').css('border','1px solid red');
        //           err_msg += "\nEmployee photo is required";
        //       }
        //       if($("#upload_resume").val()=="")
        //       {
        //           error=1;
        //           $('#upload_resume').css('border','1px solid red');
        //           err_msg += "\nEmployee Resume is required";
        //       }
        //       if($("#offer_letter").val()=="")
        //       {
        //           error=1;
        //           $('#offer_letter').css('border','1px solid red');
        //           err_msg += "\nOffer letter is required";
        //       }
        //       if($("#joining_letter").val()=="")
        //       {
        //           error=1;
        //           $('#joining_letter').css('border','1px solid red');
        //           err_msg += "\nJoining letter is required";
        //       }
        //       if($("#id_proof").val()=="")
        //       {
        //           error=1;
        //           $('#id_proof').css('border','1px solid red');
        //           err_msg += "\nId proof is required";
        //       }*/
        //     /*documents*/
        
        //     /*Bank details*/
        //       if($("#txtbankname").val()=="")
        //       {
        //           error=1;
        //           $('#txtbankname').css('border','1px solid red');
        //           err_msg += "\nBank name is required";
        //       }
        //       if($("#txtbankbranch").val()=="")
        //       {
        //           error=1;
        //           $('#txtbankbranch').css('border','1px solid red');
        //           err_msg += "\nBank branch is required";
        //       }
        //       if($("#txtaccountname").val()=="")
        //       {
        //           error=1;
        //           $('#txtaccountname').css('border','1px solid red');
        //           err_msg += "\nBank account name is required";
        //       }
        //       if($("#txtaccountno").val()=="")
        //       {
        //           error=1;
        //           $('#txtaccountno').css('border','1px solid red');
        //           err_msg += "\nBank account no is required";
        //       }
        //       if($("#txtifsccode").val()=="")
        //       {
        //           error=1;
        //           $('#txtifsccode').css('border','1px solid red');
        //           err_msg += "\nBank IFSC Code is required";
        //       }
              
        //     /*Bank details*/
        
        //     /*official details*/
        //     /*
        //       if($("#txtemployeeid").val()=="")
        //       {
        //           error=1;
        //           $('#txtemployeeid').css('border','1px solid red');
        //           err_msg += "\nEmployee Id is required";
        //       }
        //       if($("#select_branch").val()==0)
        //       {
        //           error=1;
        //           $('#select_branch').css('border','1px solid red');
        //           err_msg += "\nPlease select branch";
        //       }
        //       if($("#select_dept").val()==0)
        //       {
        //           error=1;
        //           $('#select_dept').css('border','1px solid red');
        //           err_msg += "\nPlease select department";
        //       }
        //       if($("#select_position").val()==0)
        //       {
        //           error=1;
        //           $('#select_position').css('border','1px solid red');
        //           err_msg += "\nPlease select designation";
        //       }
        //       if($("#joining_date").val()=="")
        //       {
        //           error=1;
        //           $('#joining_date').css('border','1px solid red');
        //           err_msg += "\nJoining date is required";
        //       }
        //       if($("#select_probation_time").val()==0)
        //       {
        //           error=1;
        //           $('#select_probation_time').css('border','1px solid red');
        //           err_msg += "\nPlease select probation time";
        //       }
        //       if($("#select_notice_period").val()==0)
        //       {
        //           error=1;
        //           $('#select_notice_period').css('border','1px solid red');
        //           err_msg += "\nPlease select notice period";
        //       }
        //       */
        //     /*official details*/
        
        //     /* Salary Details*/
        //     /*
        //       if($('#action').val()=="addemployee")
        //       {
        //         if($("#txtsalary").val()=="")
        //         {
        //             error=1;
        //             $('#txtsalary').css('border','1px solid red');
        //             err_msg += "\nPlease enter basic salary";
        //         }
        //         else
        //         {   
        //             var regex = /^[0-9]+$/;
        //             var input = $("#txtsalary").val();
        //             if(!regex.test(input))
        //             {
        //                 error=1;
        //                 $('#txtsalary').css('border','1px solid red');
        //                 err_msg += "\nPlease enter valid basic salary";
        //             }
        //         }
              
        //         if(type==2)
        //         {
        //             if($("#txtpoints").val()=="")
        //             {
        //                 error=1;
        //                 $('#txtpoints').css('border','1px solid red');
        //                 err_msg += "\nPlease enter target points";
        //             }
        //         }
        
        //         if(type==3)
        //         {
        //             if($("#select_kra").val()=="")
        //             {
        //                 error=1;
        //                 $('#select_kra').css('border','1px solid red');
        //                 err_msg += "\nPlease select KRA template";
        //             }
        //         }
        
        //         if($("#txthra").val()=="")
        //         {
        //             error=1;
        //             $('#txthra').css('border','1px solid red');
        //             err_msg += "\nHRA is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txthra").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txthra').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for hra";
        //           }
        //         }
        
        //         if($("#txtconveyance").val()=="")
        //         {
        //             error=1;
        //             $('#txtconveyance').css('border','1px solid red');
        //             err_msg += "\nConveyance is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtconveyance").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtconveyance').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for Conveyance";
        //           }
        //         }
        
        //         if($("#txtmdclallowance").val()=="")
        //         {
        //             error=1;
        //             $('#txtmdclallowance').css('border','1px solid red');
        //             err_msg += "\nMedical allowance is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtmdclallowance").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtmdclallowance').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for Medical allowance";
        //           }
        //         }
        
        //         if($("#txtfuelallowance").val()=="")
        //         {
        //             error=1;
        //             $('#txtfuelallowance').css('border','1px solid red');
        //             err_msg += "\nFuel allowance is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtfuelallowance").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtfuelallowance').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for Fuel allowance";
        //           }
        //         }
        
        //         if($("#txtpfamt").val()=="")
        //         {
        //             error=1;
        //             $('#txtpfamt').css('border','1px solid red');
        //             err_msg += "\nProvident fund is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtpfamt").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtpfamt').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for Provident fund";
        //           }
        //         }
        
        //         if($("#txtesiamt").val()=="")
        //         {
        //             error=1;
        //             $('#txtesiamt').css('border','1px solid red');
        //             err_msg += "\nESI is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtesiamt").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtesiamt').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for ESI";
        //           }
        //         }
        
        //         if($("#txtptamt").val()=="")
        //         {
        //             error=1;
        //             $('#txtptamt').css('border','1px solid red');
        //             err_msg += "\nProfessional tax amount is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtptamt").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtptamt').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for Professional tax";
        //           }
        //         }
        
        //         if($("#txtdbtamt").val()=="")
        //         {
        //             error=1;
        //             $('#txtdbtamt').css('border','1px solid red');
        //             err_msg += "\nAdvance tax is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txtdbtamt").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txtdbtamt').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for Advance tax";
        //           }
        //         }
        
        //         if($("#txttds").val()=="")
        //         {
        //             error=1;
        //             $('#txttds').css('border','1px solid red');
        //             err_msg += "\nTDS amount is required";
        //         }
        //         else
        //         {   
        //           var regex = /^[0-9]+$/;
        //           var input = $("#txttds").val();
        //           if(!regex.test(input))
        //           {
        //               error=1;
        //               $('#txttds').css('border','1px solid red');
        //               err_msg += "\nPlease enter valid amount for tds";
        //           }
        //         }
        //       }*/
        //     /* Salary Details*/
              
        //     if(error==1)
        //     {
        //         alert(err_msg);
        //         return false;
        //     }
        //     else
        //     {
        //         return true;
        //     }
        // }


        function get_designations(val)
        {
          return;
        }
        
        /*$('#anniversary_date').datetimepicker
        ({
          dayOfWeekStart : 1,
          lang:'en',
         
        });*/
        /*$('#txteffectivedate').datepicker({
          autoclose: true,
          minViewMode: 1,
          format: 'yyyy-mm'
        }); 
        $('#txtsalarydate').datepicker({
          autoclose: true,
          minViewMode: 1,
          format: 'yyyy-mm'
        });
        $('#txttargetdate').datepicker({
          autoclose: true,
          minViewMode: 1,
          format: 'yyyy-mm'
        });
        $('#txtsearchlog').datepicker({
          autoclose: true,
          todayHighlight: true,
          format: 'dd-mm-yyyy'
        });
        $('.personalevents').datepicker({
          autoclose: true,
          todayHighlight: true,
          format: 'dd-mm-yyyy'
        });
        */
        $(document).ready(function()
        {
                var counter = 2;
            $("#addButton").click(function()
            {
              if(counter>50)
                    {
                alert("Only 50 records Allowed");
                return false;
                    }   
                  var newTextBoxDiv = $(document.createElement('div'))
               .attr("id", 'anniversarydate1' + counter);
                  newTextBoxDiv.after().html('<div class="col-md-12"><div class="col-md-3"><div class="controls"> <label class="form-label" for="field-1">'+ "Title" + '  </label>' +
                '<input type="text" class="form-control" name="txttitle[]' + 
                '" id="txttitle' + '">' + '  </div></div>'+'<div class="col-md-3"><div class="controls"> <label class="form-label" for="field-2">'+ "Date" + '  </label>' +
                '<input type="text" class="form-control personalevents" placeholder="Eg : 12-12-2010" maxlength="10" name="txtdate[]' + 
                '" id="txtdate"'+counter + '">' + '  </div></div>'+'<div class="col-md-3"><div class="controls"><label class="form-label" for="field-3">'+ "Contact No" + '  </label>' +
                '<input type="text" class="form-control" maxlength="10" name="txtcontact[]' + 
                '" id="txtcontact' + '">'+'</div></div></div>');
                    
                          newTextBoxDiv.appendTo("#anniversarydate1");
                          counter++;
          
              $('.personalevents').datepicker
              ({
                autoclose: true,
                todayHighlight: true,
                format: 'dd-mm-yyyy'
              });
            });
          $("#removeButton").click(function () 
          {
            if(counter==1)
            {
                alert("No more textbox to remove");
                return false;
            }   
            counter--;
            $("#anniversarydate1" + counter).remove();
          });
        
          /*$('#txtdate'+counter).datetimepicker
          ({
            dayOfWeekStart : 1,
            lang:'en',
           
          });*/
        });
        
        function employee_address(val)
        {
            if(val==2)
            {
                var address = $('#txtaddress').val();
                $('#txtprmnntaddress').val(address);
            }
            else
            {
                $('#txtprmnntaddress').val('');   
            }
        }
        
        function salary_parameters(salarytype)
        {
            if(salarytype==2)
            {
              $('#slrypoints').show();
            }
            else
            {
              $('#slrypoints').hide();
            }
        
            if(salarytype==3)
            {
              $('#slrykra').show();
            }
            else
            {
              $('#slrykra').hide();
            }
        }
        
        function get_textbox(id)
        {
          if($("#leavecategory"+id).is(':checked'))
          {
            $('#probationtime'+id).show();
          }
          else
          {
            $('#probationtime'+id).hide();
          }
        }
        
        jQuery(window).load(function() 
        {
            if (location.hash !== '') {
                $('.nav-tabs a[href="' + location.hash.replace('', '') + '"]').tab('show');
            } else {
                $('.nav-tabs a:first').tab('show');
            }
        
            $('.nav-tabs a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                window.location.hash = '' + e.target.hash.substr(1);
                return false;
            });
        });
        
        function calculate_net_salary()
        {
          var basicSalary = $('#txtsalary').val();
          var basicHra = $('#txthra').val();
          var conveyance =  $('#txtconveyance').val();
          var mdclAllowance =  $('#txtmdclallowance').val();
          var fuelAllowance =  $('#txtfuelallowance').val();
          var providentFund =  $('#txtpfamt').val();
          var esi =  $('#txtesiamt').val();
          var professionalTax =  $('#txtptamt').val();
          var adv_Bvt =  $('#txtdbtamt').val();
          var tds =  $('#txttds').val();
        
          var grossSalary = 0;
          
          if(basicSalary!="")
          {
            grossSalary += parseInt(basicSalary);
          }
          if(basicHra!="")
          {
            grossSalary += parseInt(basicHra);
          }
          if(conveyance!="")
          {
            grossSalary += parseInt(conveyance);
          }
          if(mdclAllowance!="")
          {
            grossSalary += parseInt(mdclAllowance);
          }
          if(fuelAllowance!="")
          {
            grossSalary += parseInt(fuelAllowance);
          }
          
          $('#txtgrossslry').val(grossSalary);
        
          var deductions =0;
          if(providentFund!="")
          {
            deductions += parseInt(providentFund);
          }
          if(esi!="")
          {
            deductions += parseInt(esi);
          }
          if(professionalTax!="")
          {
            deductions += parseInt(professionalTax);
          }
          if(adv_Bvt!="")
          {
            deductions += parseInt(adv_Bvt);
          }
          if(tds!="")
          {
            deductions += parseInt(tds);
          }
          $('#txttotaldeduction').val(deductions);
        
          var netSalary = grossSalary-deductions;
          $('#txtnetsalary').val(netSalary);
        }