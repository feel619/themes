-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: crm_db
-- ------------------------------------------------------
-- Server version	5.7.23-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dailytask`
--

DROP TABLE IF EXISTS `dailytask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dailytask` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `projectid` int(10) NOT NULL,
  `moduleid` int(11) DEFAULT NULL,
  `description` text,
  `time` time NOT NULL,
  `task_status` tinyint(2) DEFAULT '0' COMMENT '0=Pending,1=Completed',
  `date` date NOT NULL,
  `entrydatetime` datetime NOT NULL,
  `userid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dailytask`
--

LOCK TABLES `dailytask` WRITE;
/*!40000 ALTER TABLE `dailytask` DISABLE KEYS */;
INSERT INTO `dailytask` VALUES (1,3,NULL,'RND and Database design','04:00:00',0,'2018-09-26','2018-09-26 03:48:40',2),(2,25,NULL,'API Development of Player module','04:02:00',0,'2018-09-26','2018-09-26 03:49:07',2),(3,25,NULL,'Database design','02:00:00',0,'2018-09-25','2018-09-26 03:49:31',2),(4,25,NULL,'Group Discussion','02:00:00',0,'2018-09-25','2018-09-26 03:49:48',2),(5,26,NULL,'Birthday party','01:00:00',0,'2018-09-25','2018-09-26 03:51:51',2);
/*!40000 ALTER TABLE `dailytask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project` varchar(255) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (3,'NTI',0),(25,'GM9988',0),(26,'Other',0);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contactno` varchar(50) DEFAULT NULL,
  `mobileno` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_superuser` tinyint(1) DEFAULT '0',
  `is_tl` tinyint(1) DEFAULT '0',
  `privileges` varchar(100) DEFAULT NULL,
  `auth_user` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0=Inactive 1=Active',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Not-Deleted,1=Deleted',
  `createddatetime` datetime DEFAULT NULL,
  `modifieddatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Umesh Lumbhani','8866443447','8866443447','umesh@vetron.in',1,'0000-00-00','umesh','202cb962ac59075b964b07152d234b70',1,0,'1,2,3','',1,0,'2017-11-27 15:39:07','2018-01-02 13:36:41'),(2,'Mit Patel','1234567890','2134567890','meet@vetron.in',1,'2018-11-12','mit','202cb962ac59075b964b07152d234b70',1,0,'1,2,3','2',1,0,NULL,NULL),(3,'Anil',NULL,NULL,NULL,NULL,NULL,'anil','202cb962ac59075b964b07152d234b70',0,1,'1,2,3','1,2',1,0,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_project_assign`
--

DROP TABLE IF EXISTS `user_project_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_project_assign` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `projectid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_project_assign`
--

LOCK TABLES `user_project_assign` WRITE;
/*!40000 ALTER TABLE `user_project_assign` DISABLE KEYS */;
INSERT INTO `user_project_assign` VALUES (1,1,3),(2,1,25),(3,2,3),(92,2,26),(98,2,25),(99,1,26),(111,3,3),(112,3,25);
/*!40000 ALTER TABLE `user_project_assign` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-17  2:41:47
