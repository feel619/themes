<?php
require_once(dirname(__FILE__).'/config/config.php');
require_once(dirname(__FILE__).'/config/dbconnect.php');
require_once(dirname(__FILE__).'/common/dao.php');

spl_autoload_register(function ($className) {
    $className = ltrim($className, '\\');
    $fileName  = '';
    $namespace = '';
    if ($lastNsPos = strrpos($className, '\\')) {
        $namespace = substr($className, 0, $lastNsPos);
        $className = substr($className, $lastNsPos + 1);
        $fileName  = str_replace('\\', DIRECTORY_SEPARATOR, $namespace) . DIRECTORY_SEPARATOR;
    }
    $fileName .= str_replace('', DIRECTORY_SEPARATOR, $className) . '.php';
    require_once dirname(__FILE__).'/'.$fileName;
});

global $commonurl;
if(!count($_REQUEST)) exit(0);
            
if(!isset($_REQUEST['service']) && $_REQUEST['service']!='validuser') exit(0);

if(!isset($_REQUEST['opcode']) && $_REQUEST['opcode']!='checkcredentials') exit(0);

$opcode=$_REQUEST['opcode'];
$service = $_REQUEST['service'];

$obj = new $service();
$result = $obj->$opcode();

echo $result;

class validuser
{
    private $module='validuser';
    private $encdec;
    private $Obj;
    
    function __construct()
    {
        $this->Obj = new dbconnect();
        $this->Obj->config_connect();
    }
    
    public function checkcredentials()
    {
        $username= $_POST['uname'];
        $pwd= md5($_POST['pwd']);
        
        $dao = new dao();
        $strSql = 'SELECT * FROM user WHERE username="'.$username.'" AND password="'.$pwd.'"';
        $dao->initCommand($strSql);
        $rec = $dao->executeQuery();
        if(count($rec)>0)
        {
            session_start();
            $_SESSION['prefix_crm'] = 'saas_crm';
            $_SESSION[$_SESSION['prefix_crm']]['name'] = $rec[0]['name'];
            $_SESSION[$_SESSION['prefix_crm']]['username'] = $rec[0]['username'];
            $_SESSION[$_SESSION['prefix_crm']]['userid'] = $rec[0]['id'];
            $_SESSION[$_SESSION['prefix_crm']]['is_superuser'] = $rec[0]['is_superuser'];
            $_SESSION[$_SESSION['prefix_crm']]['is_tl'] = $rec[0]['is_tl'];
            $_SESSION[$_SESSION['prefix_crm']]['auth_user'] = $rec[0]['auth_user'];
            $_SESSION[$_SESSION['prefix_crm']]['privileges'] = $rec[0]['privileges'];
            
            return json_encode(array("Success"=>"True", "Data"=> $rec[0]));
        }else{
            return json_encode(array("Success"=>"False", "Message"=>"Invalid Username and Password"));
        }
   }
}
?>