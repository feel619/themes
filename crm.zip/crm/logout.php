<?php
    session_start();
   
    unset($_SESSION['prefix_crm']);
    session_destroy();
    global $commonurl;
    header("location:$commonurl"."/index.php");
?>