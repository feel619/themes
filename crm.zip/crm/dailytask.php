<?php
class dailytask
{
    public $module='dailytask';
    public $log;
    public $encdec;
    
    public function __construct()
    {
        $this->log = new \util\logger();
    }
    public function load()
    {
        try
        {
            $this->log->logIt($this->module.' - load');
            global $twig;
            global $commonurl,$senderarr;
			
			$Obj = new \database\commondao();
			$data = $Obj->getProjectList();
			$tasks = $Obj->loadtasklist(50,0);
			$minutes = array_map('sprintf', array_fill(0, 60, '%02d'), range(1, 60));
			$hours = array_map('sprintf', array_fill(0, 12, '%02d'), range(1, 12));
			$template = $twig->loadTemplate('dailytask.html');
            
			$senderarr['commonurl'] = $commonurl;
			$senderarr['prjtlist'] = $data;
			$senderarr['hours'] = $hours;
			$senderarr['datalist'] = $tasks;
			$senderarr['minutes'] = $minutes;
			
            echo $template->render($senderarr);
        }
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - load - '.$e);
        }
    }
	public function rec($data)
    {
        try
        {
            $this->log->logIt($this->module.' - rec');
            global $twig;
            global $commonurl;
            $limit=50;
            $offset=0;
            
            if(isset($data['limit']) && $data['limit']!="")
                $limit = $data['limit'];
            if(isset($data['offset']) && $data['offset']!="")
                $offset = $data['offset'];
            
			$Obj = new \database\commondao();
			$tasks = $Obj->loadtasklist($limit,$offset);
            return $tasks;
        }
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - load - '.$e);
        }
    }
	public function addeditfrm($data)
	{
		try
        {
            $this->log->logIt($this->module.' - addeditfrm');
			$ObjCommonDao = new \database\commondao();
			$dblist = $ObjCommonDao->addedittask($data);
			
			return $dblist;
		}
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - addeditfrm - '.$e);
        }
	}
	public function remove($data)
	{
		try
        {
            $this->log->logIt($this->module.' - remove');
			$ObjCommonDao = new \database\commondao();
			$data = $ObjCommonDao->remove_task($data);
			
			return $data;
		}
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - remove - '.$e);
        }
	}
}
?>