<?php

class user
{
    public $module = 'user';
    public $log;
    public $encdec;

    public function __construct()
    {
        $this->log = new \util\logger();
    }

    public function load()
    {
        try {
            $this->log->logIt($this->module . ' - load');
            global $twig;
            global $commonurl,$senderarr;

            $Obj = new \database\user();
            $data = $Obj->getList(50, 0, "");
            $users = $Obj->getUserList();
            
            
            $ObjamenitiesDao = new \database\commondao();
            $projectdata = $ObjamenitiesDao->getList(50, 0, "");
            $projectlist = json_decode($projectdata, true);

            $senderarr['projectlist'] = $projectlist[0]['data'];
            $template = $twig->loadTemplate('user.html');

            $senderarr['commonurl'] = $commonurl;
            $senderarr['userlist'] = $users;
            
            $senderarr['datalist'] = $data;

            echo $template->render($senderarr);
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - load - ' . $e);
        }
    }

    public function rec($data)
    {
        try {
            $this->log->logIt($this->module . ' - rec');
            global $twig;
            global $commonurl;


            $limit = 50;
            $offset = 0;
            $name = "";

            if (isset($data['limit']) && $data['limit'] != "")
                $limit = $data['limit'];
            if (isset($data['offset']) && $data['offset'] != "")
                $offset = $data['offset'];
            if (isset($data['nm']) && $data['nm'] != "")
                $name = $data['nm'];


            $Obj = new \database\user();

            $data = $Obj->getList($limit, $offset, $name);
            return $data;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - load - ' . $e);
        }
    }

    public function adduser($data)
    {
        try {
            $this->log->logIt($this->module . ' - adduser');

            $data_arr = array(
                "name" => $data['name'],
                "username" => $data['username'],
                "password" => md5($data['password']),
                "is_superuser" => $data['is_superuser'],
                "is_tl" => $data['is_tl'],
                "project" => $data['project'],
                "user" => $data['user'],
                "privileges" => $data['privileges'],
                "id" => $data['id'],
                "module" => $this->module);


            $ObjCommonDao = new \database\user();
            $dblist = $ObjCommonDao->adduser($data_arr);

            return $dblist;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - adduser - ' . $e);
        }
    }

    public function remove($data)
    {
        try {
            $this->log->logIt($this->module . ' - remove');

            $ObjCommonDao = new \database\user();
            $data = $ObjCommonDao->removeuser($data);

            return $data;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - remove - ' . $e);
        }
    }


    public function getuser($data)
    {
        try {
            $this->log->logIt($this->module . ' - getuser');

            $ObjCommonDao = new \database\user();
            $dblist = $ObjCommonDao->edituser($data);

            return json_encode(array('Success' => 'True', 'Data' => $dblist));
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getuser - ' . $e);
        }
    }


}

?>