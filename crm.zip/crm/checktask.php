<?php
class checktask
{
    public $module='checktask';
    public $log;
    public $encdec;
    
    public function __construct()
    {
        $this->log = new \util\logger();
    }
    public function load()
    {
        try
        {
            $this->log->logIt($this->module.' - load');
            global $twig;
            global $commonurl,$senderarr;
			
			$Obj = new \database\commondao();
			$data = $Obj->getemployeeList();
			
			$template = $twig->loadTemplate('checktask.html');
            $retvalue = array(array("cnt"=>0,"data"=>[]));
			$senderarr['commonurl'] = $commonurl;
			$senderarr['employeelist'] = $data;
			$senderarr['datalist'] = json_encode($retvalue);
			
            echo $template->render($senderarr);
        }
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - load - '.$e);
        }
    }
	public function rec($data)
    {
        try
        {
            $this->log->logIt($this->module.' - rec');
            global $twig;
            global $commonurl;
            $limit=50;
            $offset=0;
            $emp = $_SESSION[$_SESSION['prefix_crm']]['userid'];
            if(isset($data['limit']) && $data['limit']!="")
                $limit = $data['limit'];
            if(isset($data['offset']) && $data['offset']!="")
                $offset = $data['offset'];
            if(isset($data['emp']) && $data['emp']!="")
                $emp = $data['emp'];

			$Obj = new \database\commondao();
			$tasks = $Obj->loadtasklist($limit,$offset,$emp);
            return $tasks;
        }
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - load - '.$e);
        }
    }
	public function addeditfrm($data)
	{
		try
        {
            $this->log->logIt($this->module.' - addeditfrm');
			$ObjCommonDao = new \database\commondao();
			$dblist = $ObjCommonDao->addedittask($data);
			
			return $dblist;
		}
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - addeditfrm - '.$e);
        }
	}
}
?>