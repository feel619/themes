<?php

class projects
{
    public $module = 'projects';
    public $log;
    public $encdec;

    public function __construct()
    {
        $this->log = new \util\logger();
    }

    public function load()
    {
        try {
            $this->log->logIt($this->module . ' - load');
            global $twig;
            global $commonurl,$senderarr;

            $Obj = new \database\commondao();
            $data = $Obj->getList(50, 0, "");
            //$this->log->logIt($data);
            //$tasks = $Obj->loadtasklist(50,0,"");
            $template = $twig->loadTemplate('projects.html');

            $senderarr['commonurl'] = $commonurl;
            $senderarr['prjtlist'] = $data;
            //$senderarr['datalist'] = $tasks;

            echo $template->render($senderarr);
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - load - ' . $e);
        }
    }

    public function rec($data)
    {
        try {
            $this->log->logIt($this->module . ' - rec');
            global $twig;
            global $commonurl;


            $limit = 50;
            $offset = 0;
            $name = "";

            if (isset($data['limit']) && $data['limit'] != "")
                $limit = $data['limit'];
            if (isset($data['offset']) && $data['offset'] != "")
                $offset = $data['offset'];
            if (isset($data['nm']) && $data['nm'] != "")
                $name = $data['nm'];


            $Obj = new \database\commondao();
            $data = $Obj->getList($limit, $offset, $name);
            return $data;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - load - ' . $e);
        }
    }

    public function addprojects($data)
    {
        try {
            $this->log->logIt($this->module . ' - addprojects');

            $data_arr = array(
                "project" => $_POST['projects'],
                "id" => $data['id'],
                "module" => $this->module);

            $this->log->logIt($data_arr);
            $ObjCommonDao = new \database\commondao();
            $dblist = $ObjCommonDao->addprojects($data_arr);

            return $dblist;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - addprojects - ' . $e);
        }
    }

    public function remove($data)
    {
        try {
            $this->log->logIt($this->module . ' - remove');
            $this->log->logIt($data);
            $ObjCommonDao = new \database\commondao();
            $data = $ObjCommonDao->removeproject($data);

            return $data;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - remove - ' . $e);
        }
    }


    public function getproject($data)
    {
        try {
            $this->log->logIt($this->module . ' - getproject');

            $ObjCommonDao = new \database\commondao();
            $dblist = $ObjCommonDao->getproject($data);
            // $this->log->logIt($data);
            return $dblist;
        } catch (Exception $e) {
            $this->log->logIt($this->module . ' - getproject - ' . $e);
        }
    }


}

?>