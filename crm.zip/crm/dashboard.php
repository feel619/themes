<?php
class dashboard
{
    public $module='dashboard';
    public $log;
    public $encdec;
    
    public function __construct()
    {
        $this->log = new \util\logger();
    }
    public function load()
    {
        try
        {
            $this->log->logIt($this->module.' - load');
            global $twig;
            global $commonurl,$senderarr;
			$all = 0;
			if($_SESSION[$_SESSION['prefix_crm']]['is_tl']=='1' || $_SESSION[$_SESSION['prefix_crm']]['is_superuser']=='1')
			{
				$all = 1;
			}
			
			$template = $twig->loadTemplate('dashboard.html');
            $senderarr['commonurl'] = $commonurl;
			$senderarr['user'] = $_SESSION[$_SESSION['prefix_crm']]['username'];
			$senderarr['super_user'] = $all;
            echo $template->render($senderarr);
        }
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - load - '.$e);
        }
    }
	public function getDbList()
	{
		try
        {
            $this->log->logIt($this->module.' - getDbList');
			$ObjCommonDao = new \database\commondao();
			$dblist = $ObjCommonDao->getdatabaselistwithsize();
			
			return json_encode(array("Success"=>"True", "Data"=>$dblist));
		}
        catch(Exception $e)
        {
            $this->log->logIt($this->module.' - getDbList - '.$e);
        }
	}
}
?>